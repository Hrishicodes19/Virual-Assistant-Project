import sys
from PyQt5.uic import loadUi
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QDialog, QApplication, QWidget
from PyQt5.QtCore import *
from PyQt5.QtGui import QMovie
from PyQt5.QtGui import *
import sqlite3


class Welcomescreen(QDialog):
	def __init__(self):
		super(Welcomescreen, self).__init__()
		loadUi("Welcomescreen.ui", self)
		self.login.clicked.connect(self.gotologin)
		self.create.clicked.connect(self.gotocreate)


	def gotologin(self):
		login = LoginScreen()
		widget.addWidget(login)
		widget.setCurrentIndex(widget.currentIndex()+1)

	def gotocreate(self):
		create = CreateAccScreen()
		widget.addWidget(create)
		widget.setCurrentIndex(widget.currentIndex() + 1)


class LoginScreen(QDialog):
	def __init__(self):
		super(LoginScreen, self).__init__()
		loadUi("login.ui", self)
		self.passwordfield.setEchoMode(QtWidgets.QLineEdit.Password)
		self.login.clicked.connect(self.loginfunction)

	def loginfunction(self):
		user = self.emailfield.text()
		password = self.passwordfield.text()

		if len(user)==0 or len(password)==0:
			self.error.setText("Please input all fields.")

		else:
			conn = sqlite3.connect("vision_user_data.db")
			cur = conn.cursor()
			query = 'SELECT password FROM login_info WHERE username =\''+user+"\'"
			cur.execute(query)
			result_pass = cur.fetchone()[0]
			if result_pass == password:
				print("Successfully logged in.")
				self.error.setText("")
				login = Home()
				widget.addWidget(login)
				widget.setCurrentIndex(widget.currentIndex() + 1)
			else:
				self.error.setText("Invalid username or password.")




class CreateAccScreen(QDialog):
	def __init__(self):
		super(CreateAccScreen, self).__init__()
		loadUi("signup.ui", self)
		self.passwordfield.setEchoMode(QtWidgets.QLineEdit.Password)
		self.confirmpasswordfield.setEchoMode(QtWidgets.QLineEdit.Password)
		self.signup.clicked.connect(self.signupfunction)

	def signupfunction(self):
		user = self.emailfield.text()
		password = self.passwordfield.text()
		confirmpassword = self.confirmpasswordfield.text()

		if len(user)==0 or len(password)==0 or len(confirmpassword)==0:
			self.error.setText("Please fill in all inputs.")

		elif password!=confirmpassword:
			self.error.setText("Password do not match.")

		else:
			conn = sqlite3.connect("vision_user_data.db")
			cur = conn.cursor()

			user_info = [user, password]
			cur.execute('INSERT INTO login_info (username, password) VALUES (?,?)', user_info)

			conn.commit()
			conn.close()


class Home(QDialog):
	def __init__(self):
		super(Home, self).__init__()
		loadUi("Homevision.ui", self)



			#fillprofile = FillProfileScreen()
			#widget.addWidget(fillprofile)
			#widget.setCurrentIndex(widget.currentIndex()+1)

#class FillProfileScreen(QDialog):

		


		
		
		


app = QApplication(sys.argv)
welcome = Welcomescreen()
widget = QtWidgets.QStackedWidget()
widget.addWidget(welcome)
widget.setFixedHeight(800)
widget.setFixedWidth(1200)
widget.show()
try:
	sys.exit(app.exec_())
except:
	print("Exiting")