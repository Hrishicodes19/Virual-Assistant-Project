import sys
from PyQt5.uic import loadUi
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QDialog, QApplication, QWidget
from PyQt5.QtCore import *
from PyQt5.QtGui import QMovie
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt, QTimer, QTime, QDate
import sqlite3
from Homevision import *
import speech_recognition as sr
import pyttsx3
import datetime
import time
from bs4 import BeautifulSoup
import requests
import os
import cv2
import requests
from requests import get
import wikipedia
import webbrowser
import pywhatkit as kit
import pyautogui
import PyPDF2
import smtplib
import base64
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import mailparser
import email_pass





class Welcomescreen(QDialog):
	def __init__(self):
		super(Welcomescreen, self).__init__()
		loadUi("Welcomescreen.ui", self)
		self.login.clicked.connect(self.gotologin)
		self.create.clicked.connect(self.gotocreate)


	def gotologin(self):
		login = LoginScreen()
		widget.addWidget(login)
		widget.setCurrentIndex(widget.currentIndex()+1)

	def gotocreate(self):
		create = CreateAccScreen()
		widget.addWidget(create)
		widget.setCurrentIndex(widget.currentIndex() + 1)


class LoginScreen(QDialog):
	def __init__(self):
		super(LoginScreen, self).__init__()
		loadUi("login.ui", self)
		self.passwordfield.setEchoMode(QtWidgets.QLineEdit.Password)
		self.login.clicked.connect(self.loginfunction)

	def loginfunction(self):
		user = self.emailfield.text()
		password = self.passwordfield.text()

		if len(user)==0 or len(password)==0:
			self.error.setText("Please input all fields.")

		else:
			conn = sqlite3.connect("vision_user_data.db")
			cur = conn.cursor()
			query = 'SELECT password FROM login_info WHERE username =\''+user+"\'"
			cur.execute(query)
			result_pass = cur.fetchone()[0]
			if result_pass == password:
				print("Successfully logged in.")
				self.error.setText("")
				login = Home()
				widget.addWidget(login)
				widget.setCurrentIndex(widget.currentIndex() + 1)
			else:
				self.error.setText("Invalid username or password.")




class CreateAccScreen(QDialog):
	def __init__(self):
		super(CreateAccScreen, self).__init__()
		loadUi("signup.ui", self)
		self.passwordfield.setEchoMode(QtWidgets.QLineEdit.Password)
		self.confirmpasswordfield.setEchoMode(QtWidgets.QLineEdit.Password)
		self.signup.clicked.connect(self.signupfunction)

	def signupfunction(self):
		user = self.emailfield.text()
		password = self.passwordfield.text()
		confirmpassword = self.confirmpasswordfield.text()

		if len(user)==0 or len(password)==0 or len(confirmpassword)==0:
			self.error.setText("Please fill in all inputs.")

		elif password!=confirmpassword:
			self.error.setText("Password do not match.")

		else:
			conn = sqlite3.connect("vision_user_data.db")
			cur = conn.cursor()

			user_info = [user, password]
			cur.execute('INSERT INTO login_info (username, password) VALUES (?,?)', user_info)

			conn.commit()
			conn.close()
			self.gotofirst()



	def gotofirst(self):
		signup = Home()
		widget.addWidget(signup)
		widget.setCurrentIndex(widget.currentIndex() + 1)



# this for speak function voice generation
engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
print(voices)
engine.setProperty('voice',voices[0].id)

def speak(audio):
    engine.say(audio)
    print(audio)
    engine.runAndWait()




class HomeThread(QThread):
	def __init__(self):
		super(HomeThread,self).__init__()


	def takecommand(self):
		r = sr.Recognizer()
		with sr.Microphone() as source:
			print("listening...")
			r.pause_threshold = 1
			# r.adjust_for_ambient_noise(source)
			# audio = r.listen(source)
			audio = r.listen(source,timeout=40,phrase_time_limit=7)

		try:
			print("Recognizing...")
			query = r.recognize_google(audio, language='en-in')
			print(f"user said: {query}")

		except Exception as e:
			# speak("Say that again please...")
			return "none"
		query = query.lower()
		return query


	def run(self):
		self.wish()
		self.Taskexecution()
		


	def wish(self):
		hour = int(datetime.datetime.now().hour)
		tt = time.strftime("%I:%M %p")

		if hour >= 0 and hour <= 12:
			speak(f"good morning, its {tt}")
		elif hour >= 12 and hour <= 18:
			speak(f"good afternoon, its {tt}")
		else:
			speak(f"good evening, its {tt}")
		speak("all system check, initiating all system drivers...")
		speak("My name is vision, i am your virtual assistant")
		speak("i am online boss. please tell me how may i help you")

		
	def Taskexecution(self):
		while True:
			self.query = self.takecommand()


			if "open notepad" in self.query:
				npath = "C:\\WINDOWS\\system32\\notepad.exe" #enter your sys app path here might have diff in your sys.
				os.startfile(npath)

			elif "open paint" in self.query:
				ppath = "C:\\WINDOWS\\system32\\mspaint.exe" #enter your sys app path here might have diff in your sys.
				os.startfile(ppath)

			elif "open wordpad" in self.query:
				wpath = "C:\\Program Files\\Windows NT\\Accessories\\wordpad.exe" #enter your sys app path here might have diff in your sys.
				os.startfile(wpath)

			elif "open command prompt" in self.query:
				os.system("start cmd")

			elif "open camera" in self.query:
				cap = cv2.VideoCapture(0)
				while True:
					ret, img = cap.read()
					cv2.imshow('webcam', img)
					k = cv2.waitKey(50)
					if k==27:
						break;
				cap.release()
				cv2.destroyAllWindows()

			elif "play music" in self.query:
				music_dir = "E:\\Favourite songs" # enter the path of your music directory(plz only include audio file)
				songs = os.listdir(music_dir)
				os.startfile(os.path.join(music_dir, songs[0]))

			elif "ip address" in self.query:
				ip = get('https://api.ipify.org').text
				speak(f"your IP address is {ip}")

			elif "search on wikipedia" in self.query:
				speak("searching wikipedia...")
				query = query.replace("wikipedia","")
				results = wikipedia.summary(query, sentences=5)
				speak("according to wikipedia")
				speak(results)
				#print(results)

			elif "open youtube" in self.query:
				webbrowser.open("www.youtube.com")

			elif "open kaggle" in self.query:
				webbrowser.open("www.kaggle.com")

			elif "open twitter" in self.query:
				webbrowser.open("https://twitter.com/?lang=en")

			elif "open google" in self.query:
				speak("boss, what should i search on google")
				cm = self.takecommand()
				webbrowser.open(f"{cm}")

			elif "open github" in self.query:
				webbrowser.open("www.github.com")

			elif "open stackoverflow" in self.query:
				webbrowser.open("www.stackoverflow.com")

			elif "find details about today's cricket match" in self.query:
				webbrowser.open("www.cricbuzz.com")

			elif "play songs on youtube" in self.query:
				speak("which song do you want to play")
				asksong = self.takecommand()
				kit.playonyt(f"{asksong}")

			elif "close notepad" in self.query:
				speak("okay sir, closing notepad")
				os.system("taskkill /f /im notepad.exe")

			elif "close paint" in self.query:
				speak("okay sir, closing notepad")
				os.system("taskkill /f /im mspaint.exe")

			elif "close wordpad" in self.query:
				speak("okay sir, closing notepad")
				os.system("taskkill /f /im wordpad.exe")

			elif "switch the window" in self.query:
				pyautogui.keyDown("alt")
				pyautogui.press("tab")
				time.sleep(1)
				pyautogui.keyUp("alt")

			elif "read pdf" in self.query:
				self.pdf_reader()

			elif "remember that" in self.query:
				rememberMsg = self.query.replace("remember that","")
				rememberMsg = rememberMsg.replace("vision","")
				speak("you tell me to remind you that :"+rememberMsg)
				remember = open('data.txt','w')
				remember.write(rememberMsg)
				remember.close()

			elif "what do you remember" in self.query:
				remember = open('data.txt','r')
				speak("you tell me that" + remember.read())




			elif "hello vision" in self.query or "hello" in self.query:
				speak("hello boss, may i help you with something")

			elif "tell me more about yourself" in self.query or "tell me about your feature" in self.query:
				speak("ok boss, my name is vision, i am your assistant and a product of artificial intelligence.")
				speak("i can make reminders, open many system applications, can help on searching on browser.")
				speak("i can also send email.")
				speak("when you get bored i can play a song for you, and can tell you news.")


			elif "go offline" in self.query:
				speak("ok boss, thank you for allowing me to serve you.")
				speak("you can call me anytime")
				break

			elif "send a mail" in self.query:

				speak("sir what should i say")
				self.query = self.takecommand()
				if "send a file" in self.query:
					email = 'yourmail@gmail.com' # Your email
					password = 'password' # Your email account password
					send_to_email = 'personemail@gmail.com' # Whom you are sending the message to
					speak("okay sir, what is the subject for this email")
					self.query = self.takecommand()
					subject = self.query   # The Subject in the email
					speak("and sir, what is the message for this email")
					self.query2 = self.takecommand()
					message = self.query2  # The message in the email
					speak("sir please enter the correct path of the file into the shell")
					file_location = input("please enter the path here")    # The File attachment in the email

					speak("please wait,i am sending email now")
					msg = MIMEMultipart()
					msg['From'] = email
					msg['To'] = send_to_email
					msg['Subject'] = subject

					msg.attach(MIMEText(message, 'plain'))

				# Setup the attachment
					filename = os.path.basename(file_location)
					attachment = open(file_location, "rb")
					part = MIMEBase('application', 'octet-stream')
					part.set_payload(attachment.read())
					encoders.encode_base64(part)
					part.add_header('Content-Disposition', "attachment; filename= %s" % filename)

					# Attach the attachment to the MIMEMultipart object
					msg.attach(part)
					server = smtplib.SMTP('smtp.gmail.com', 587)
					server.starttls()
					server.login(email, password)
					text = msg.as_string()
					server.sendmail(email, send_to_email, text)
					server.quit()
					speak("email has been sent to avinash")

				else:
					email = 'yourmail@gmail.com' # Your email
					password = 'password' # Your email account password
					send_to_email = 'personemail@gmail.com' # Whom you are sending the message to
					message = self.query # The message in the email

					server = smtplib.SMTP('smtp.gmail.com', 587) # Connect to the server
					server.starttls() # Use TLS
					server.login(email, password) # Login to the email server
					server.sendmail(email, send_to_email , message) # Send the email
					server.quit() # Logout of the email server
					speak("email has been sent to avinash")





	def pdf_reader(self):
		# please store all book in the same project file.
		speak("which book you want to read")
		self.askforbook = self.takecommand().lower()
		try:
			if "algorithm" in self.askforbook: # make any name for book
				book = open('clrs.pdf', 'rb') # nameofthatpdf.pdf
			elif "computer network" in self.askforbook:# 2nd book name
				book = open('Computer Network 5th Edition.pdf', 'rb') # nameofthatpdf.pdf
			elif "programming" in self.askforbook: # 3rd book name
				book = open('book.pdf', 'rb') # nameofthatpdf.pdf
		except Exception as e:
			speak("i didn't recognized")

		pdfReader = PyPDF2.PdfFileReader(book) #pip install PyPDF2
		pages = pdfReader.numPages
		speak(f"Total numbers of pages in this book {pages} ")
		speak("sir please enter the page number i have to read")
		pg = int(input("Please enter the page number: "))
		page = pdfReader.getPage(pg)
		text = page.extractText()
		speak(text)





startExecution = HomeThread()


class Home(QDialog):
	def __init__(self):
		super(Home, self).__init__()
		#loadUi("Homevision.ui", self)

		self.gui = Ui_Form()
		self.gui.setupUi(self)

		self.gui.start.clicked.connect(self.startTask)
		self.gui.news_bt.clicked.connect(self.gotonews)
		self.gui.exit.clicked.connect(self.escape)

	def startTask(self):

		self.gui.label1 = QtGui.QMovie("Circle2.gif")
		self.gui.gif_1.setMovie(self.gui.label1)
		self.gui.label1.start()


		self.gui.label2 = QtGui.QMovie("BigheartedVagueFoal-size_restricted.gif")
		self.gui.gif_2.setMovie(self.gui.label2)
		self.gui.label2.start()

		timer = QTimer(self)
		timer.timeout.connect(self.showTimeLive)
		timer.start(111)
		startExecution.start()


	def escape(self):

		sys.exit()



	def showTimeLive(self):
		t_time = QTime.currentTime()
		time = t_time.toString()
		d_ate = QDate.currentDate()
		date = d_ate.toString()
		label_time = "Time :" + time
		label_date = "Date :" + date



		self.gui.timetextBrowser.setText(label_time)
		self.gui.datetextBrowser_2.setText(label_date)






	def gotonews(self):
		news = NewsApi()
		widget.addWidget(news)
		widget.setCurrentIndex(widget.currentIndex() + 1)


class NewsThread(QThread):
	def __init__(self):
		super(NewsThread,self).__init__()



	def run(self):
		self.Newsstart()



	def Newsstart(self):
		main_url = "http://newsapi.org/v2/top-headlines?sources=techcrunch&apiKey=3cc73e32ae3946f490b542d064fc02d8"
		main_page = requests.get(main_url).json()
		#print(main_page)
		articles = main_page["articles"]
		#print(articles)
		head = []
		day=["first","second","third","fourth","fifth","sixth","seventh","eighth","ninth","tenth"]


		for ar in articles:
			#self.gui.newsfeedtextw.append(ar["title"])
			head.append(ar["title"])
			
		for i in range (len(day)):
			#print(f"today's {day[i]} news is: ", head[i])
			speak(f"today's {day[i]} news is: {head[i]}")


newsExecution = NewsThread()




class NewsApi(QDialog):
	def __init__(self):
		super(NewsApi, self).__init__()
		from newsapi import Ui_Form
		self.gui = Ui_Form()
		self.gui.setupUi(self)

		self.gui.label3 = QtGui.QMovie("assistant.gif")
		self.gui.gif_assist.setMovie(self.gui.label3)
		self.gui.label3.start()

		self.gui.label4 = QtGui.QMovie("Loading-Bar.gif")
		self.gui.gif_load.setMovie(self.gui.label4)
		self.gui.label4.start()

		self.gui.pressfornews.clicked.connect(self.startgui)
		self.gui.back.clicked.connect(self.mainmenu)

	def mainmenu(self):
		main = Home()
		widget.addWidget(main)
		widget.setCurrentIndex(widget.currentIndex() + 1)


	def startgui(self):
		main_url = "http://newsapi.org/v2/top-headlines?sources=techcrunch&apiKey=3cc73e32ae3946f490b542d064fc02d8"
		main_page = requests.get(main_url).json()
		#print(main_page)
		articles = main_page["articles"]
		#print(articles)
		head = []
		day=["first","second","third","fourth","fifth","sixth","seventh","eighth","ninth","tenth"]


		for ar in articles:
			self.gui.newsfeedtextw.append(ar["title"])
			head.append(ar["title"])
			newsExecution.start()
			
		#for i in range (len(day)):
			#print(f"today's {day[i]} news is: ", head[i])
			#speak(f"today's {day[i]} news is: {head[i]}")


	'''def tellnews(self):
		main_url = "http://newsapi.org/v2/top-headlines?sources=techcrunch&apiKey=3cc73e32ae3946f490b542d064fc02d8"
		main_page = requests.get(main_url).json()
		#print(main_page)
		articles = main_page["articles"]
		#print(articles)
		head = []
		day=["first","second","third","fourth","fifth"]
		#for ar in articles:
			#head.append(ar["title"])
		#for i in range (len(day)):
			#print(f"today's {day[i]} news is: ", head[i])
			#speak(f"today's {day[i]} news is: {head[i]}")'''





		


		
		
		
app = QApplication(sys.argv)
welcome = Welcomescreen()
widget = QtWidgets.QStackedWidget()
widget.addWidget(welcome)
widget.setFixedHeight(800)
widget.setFixedWidth(1200)
widget.show()
try:
	sys.exit(app.exec_())
except:
	print("Exiting")